package com.company;

public class VNode {
    VertexType data;
    ArcNode firstarc;

    public VNode(VertexType data, ArcNode firstarc) {
        this.data = data;
        this.firstarc = firstarc;
    }

    public VertexType getData() {
        return data;
    }

    public void setData(VertexType data) {
        this.data = data;
    }

    public ArcNode getFirstarc() {
        return firstarc;
    }

    public void setFirstarc(ArcNode firstarc) {
        this.firstarc = firstarc;
    }
}
