package com.company;

public class ArcNode {
    int adjvex;//另一个顶点在图中的id
    ArcNode nextarc;
    double weight;

    public ArcNode(int adjvex, ArcNode nextarc, double weight) {
        this.adjvex = adjvex;
        this.nextarc = nextarc;
        this.weight = weight;
    }

    public int getAdjvex() {
        return adjvex;
    }

    public void setAdjvex(int adjvex) {
        this.adjvex = adjvex;
    }

    public ArcNode getNextarc() {
        return nextarc;
    }

    public void setNextarc(ArcNode nextarc) {
        this.nextarc = nextarc;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
